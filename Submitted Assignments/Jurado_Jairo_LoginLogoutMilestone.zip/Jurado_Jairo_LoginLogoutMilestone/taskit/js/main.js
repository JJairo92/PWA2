/*
Description: DESCRIPTION INFO GOES HERE
1Main.js
*/

$(function(){

	var container = $('#wrapper');

	var loadLanding = function() {
		container.empty();

		$.get('templates/landing.html', function(html){
			var landingCode = $(html).find('#header-temp').html();
			$.template('landing', landingCode);		// compile template
			var landingTemp = $.render('', 'landing');		// use template
			container.append(landingCode);

			$('#login-button').on('click', function(e) {
				e.preventDefault();

				login();
			})

			$('#signup-button').on('click', function(e) {
				e.preventDefault();

				loadApp();
			})
		});
	};	

	var checkLoginState = function() {
		$.ajax({
			url: 'xhr/check_login.php',
			type: 'get',
			dataType: 'json',
			success: function(response) {
				if(response.user) {
					loadApp();
				} else {
					loadLanding();
				}
			}
		});
	};

	var getProjects = function() {
		$.ajax({
			url: 'xhr/get_projects.php',
			type: 'get',
			dataType: 'json',
			success: function(response) {
				console.log(response);

				$.get('templates/app.html', function(html){
					var projectCode = $(html).find('#projects-content').html();
					$.template('projectTemp', projectCode);		// compile template
					var projectTemp = $.render(response.projects, 'projectTemp');		// use template
					$('#box-container').append(projectTemp);
				});
			}
		});
	};

	var loadApp = function() {

		container.empty();

		$.get('templates/app.html', function(html){
			var appCode = $(html).find('#header-app').html();
			$.template('appHeader', appCode);		// compile template
			var appHeader = $.render('', 'appHeader');		// use template
			container.append(appHeader);

			$('#logout-button').on('click', function(e) {
				e.preventDefault();

				$.get('xhr/logout.php', function() {
					loadLanding();
				});

				return false;
			})
		});

		$.get('templates/app.html', function(html){
			var appCode = $(html).find('#view-projects').html();
			$.template('create-project-button', appCode);		// compile template
			var projectButton = $.render('', 'create-project-button');		// use template
			container.append(projectButton);

			getProjects();
		});

	};

	var login = function() {
		var user = $('#username').val();
		var pass = $('#password').val();


		$.ajax({
			url: 'xhr/login.php',
			data: {
				username: user,
				password: pass
			},
			type: 'post',
			dataType: 'json',
			success: function(response) {
				if(response.error) {
					console.log(response.error);
				} else {
					console.log(response.user);

					loadApp();
				}
			}
		});
	}

	var init = function() {
		checkLoginState();
	};	
	
	init();
});